package main

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"net"
	"time"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/google/gopacket/pcap"
)

var (
	vlan_netdevice_handle *pcap.Handle
	vlan_copier_started   bool = false
)

func vlan_start() {
	if !vlan_open_netdevice() {
		return
	}
	vlan_start_data_copier()
}

func vlan_list_all_net_device() []pcap.Interface {
	ifs, err := pcap.FindAllDevs()
	if err != nil {
		custom_log("Error", "Failed to list net devices: %v", err)
		return make([]pcap.Interface, 0)
	}
	return ifs
}

func vlan_open_netdevice() bool {
	if vlan_netdevice_handle != nil {
		custom_log("Debug", "Closing existing handle")
		(*vlan_netdevice_handle).Close()
		vlan_netdevice_handle = nil
	}
	handle, err := pcap.OpenLive(MainProgramConfig.Vlan.NetDevice, 1600, true, pcap.BlockForever)
	if err != nil {
		custom_log("Error", "Failed to open device %s: %v", MainProgramConfig.Vlan.NetDevice, err)
		return false
	}
	filter := fmt.Sprintf("(ip and dst host %s) or (arp and dst host %s and arp[6:2] = 1)", MainProgramConfig.Vlan.RemoteIP, MainProgramConfig.Vlan.RemoteIP)
	//filter := fmt.Sprintf("ip and dst host %s", MainProgramConfig.Vlan.RemoteIP)
	if err := handle.SetBPFFilter(filter); err != nil {
		custom_log("Error", "Failed to set BPF filter %s: %v", filter, err)
		handle.Close()
		return false
	}
	vlan_netdevice_handle = handle
	return true
}

func vlan_start_data_copier() {
	if vlan_netdevice_handle == nil {
		custom_log("Error", "Vlan net device not opened")
		return
	}
	if vlan_copier_started {
		custom_log("Warn", "Vlan data copier is already started")
		return
	}

	go func() {
		for {
			packet_source := gopacket.NewPacketSource(vlan_netdevice_handle, vlan_netdevice_handle.LinkType())
			custom_log("Info", "(Re)Created PacketSource")
			for packet := range packet_source.Packets() {
				custom_log("Trace", "NetDevice received eth packet")
				if hook_arp_handler(packet) { // check and block arp request
					continue
				}
				if hy2_quic_conn_stream == nil {
					//custom_log("Trace", "hy2_quic_conn_stream is nil, dropping this packet")
					continue
				}
				modified_packet := vlan_modify_packet_on_send(packet)
				if len(modified_packet) <= 0 {
					custom_log("Warn", "Failed to send packet to remote: Packet length <= 0")
					continue
				}
				packet_len := len(modified_packet)
				if packet_len > 0xffff {
					custom_log("Logic Error", "Failed to send packet to remote: Packet length > 65535")
					continue
				}
				modified_packet = append([]byte{0, 0}, modified_packet...)
				binary.BigEndian.PutUint16(modified_packet[:2], uint16(packet_len))
				if _, err := (*hy2_quic_conn_stream).Write(modified_packet); err != nil {
					custom_log("Warn", "Failed to send packet (%d bytes) to remote: %v", len(modified_packet), err)
				} else {
					custom_log("Trace", "Hy2 conn sent packet to remote: %d bytes", len(modified_packet))
				}
			}
			time.Sleep(500 * time.Millisecond)
		}
		custom_log("Logic Error", "vlan_start_data_copier().loop0 returns unexpectedly")
	}()

	go func() {
		var packet_buffer []byte
		read_buffer := make([]byte, 1600)
		var packet_len uint16 = 0
		for {
			if hy2_quic_conn_stream == nil {
				//custom_log("Trace", "hy2_quic_conn_stream is nil, skipping read")
				time.Sleep(500 * time.Millisecond)
				continue
			}
			n, err := (*hy2_quic_conn_stream).Read(read_buffer)
			if err != nil {
				custom_log("Error", "Failed to read from remote: %v", err)
				time.Sleep(500 * time.Millisecond)
				continue
			}
			custom_log("Trace", "Hy2 conn recv from remote: %d bytes", n)
			packet_buffer = append(packet_buffer, read_buffer[:n]...)
			for {
				if packet_len <= 0 {
					if len(packet_buffer) < 2 {
						break
					}
					packet_len = binary.BigEndian.Uint16(packet_buffer[:2])
					packet_buffer = packet_buffer[2:]
				}
				if len(packet_buffer) < int(packet_len) {
					break
				}
				packet := packet_buffer[:packet_len]
				packet_buffer = packet_buffer[packet_len:]
				packet_len = 0
				modified_packet := vlan_modify_packet_on_recv(packet)
				if len(modified_packet) <= 0 {
					custom_log("Warn", "Failed to send packet to local network: Packet length <= 0")
					break
				}
				if err := vlan_netdevice_handle.WritePacketData(modified_packet); err != nil {
					custom_log("Trace", "Failed to send packet (%d bytes) to local network: %v", len(modified_packet), err)
				} else {
					custom_log("Trace", "Sent packet to local network: %d bytes", len(modified_packet))
				}
				break
			}
		}
		custom_log("Logic Error", "vlan_start_data_copier().loop1 returns unexpectedly")
	}()

	go vlan_arp_announce_loop()
}

func vlan_modify_packet_on_send(packet gopacket.Packet) []byte {
	if packet.LinkLayer() == nil {
		return packet.Data()
	}

	layer_eth, ok := packet.LinkLayer().(*layers.Ethernet)
	if !ok {
		return packet.Data()
	}

	(*layer_eth).SrcMAC = MainProgramConfig.Vlan.LocalMac_obj
	if !bytes.Equal((*layer_eth).DstMAC, []byte{0xff, 0xff, 0xff, 0xff, 0xff, 0xff}) {
		(*layer_eth).DstMAC = MainProgramConfig.Vlan.RemoteMac_obj
	}

	if packet.NetworkLayer() == nil {
		return packet.Data()
	}

	if packet.NetworkLayer() == nil {
		return packet.Data()
	}
	layer_ipv4, ok := packet.NetworkLayer().(*layers.IPv4)
	if !ok {
		return packet.Data()
	}

	(*layer_ipv4).SrcIP = MainProgramConfig.Vlan.LocalIP_obj
	(*layer_ipv4).DstIP = MainProgramConfig.Vlan.RemoteIP_obj

	_, ok = packet.TransportLayer().(*layers.TCP)
	if ok {
		packet.TransportLayer().(*layers.TCP).SetNetworkLayerForChecksum(packet.NetworkLayer())
	} else {
		_, ok = packet.TransportLayer().(*layers.UDP)
		if ok {
			packet.TransportLayer().(*layers.UDP).SetNetworkLayerForChecksum(packet.NetworkLayer())
		} else {
			custom_log("Error", "Unsupported TransportLayer type")
			return []byte{}
		}
	}

	buffer := gopacket.NewSerializeBuffer()
	opts := gopacket.SerializeOptions{
		FixLengths:       true,
		ComputeChecksums: true,
	}
	err := gopacket.SerializePacket(buffer, opts, packet)
	if err != nil {
		custom_log("Error", "Failed to serialize layers for modified packet: %v", err)
		return []byte{}
	}
	return buffer.Bytes()
}

func vlan_modify_packet_on_recv(data []byte) []byte {
	packet := gopacket.NewPacket(data, layers.LayerTypeEthernet, gopacket.DecodeOptions{
		Lazy:                     true,
		NoCopy:                   true,
		SkipDecodeRecovery:       false,
		DecodeStreamsAsDatagrams: false,
	})
	if packet.NetworkLayer() == nil {
		custom_log("Trace", "Incoming packet missing NetworkLayer")
		return packet.Data()
	}
	layer_ipv4, ok := packet.NetworkLayer().(*layers.IPv4)
	if !ok {
		custom_log("Trace", "Incoming packet's NetworkLayer is not IPv4")
		return packet.Data()
	}
	(*layer_ipv4).SrcIP = MainProgramConfig.Vlan.RemoteIP_obj
	if !bytes.Equal((*layer_ipv4).DstIP, []byte{0xff, 0xff, 0xff, 0xff}) {
		(*layer_ipv4).DstIP = MainProgramConfig.Vlan.RealLocalIP_obj
	}

	_, ok = packet.TransportLayer().(*layers.TCP)
	if ok {
		packet.TransportLayer().(*layers.TCP).SetNetworkLayerForChecksum(packet.NetworkLayer())
	} else {
		_, ok = packet.TransportLayer().(*layers.UDP)
		if ok {
			packet.TransportLayer().(*layers.UDP).SetNetworkLayerForChecksum(packet.NetworkLayer())
		} else {
			custom_log("Error", "Unsupported TransportLayer type")
			return []byte{}
		}
	}

	buffer := gopacket.NewSerializeBuffer()
	opts := gopacket.SerializeOptions{
		FixLengths:       true,
		ComputeChecksums: true,
	}
	err := gopacket.SerializePacket(buffer, opts, packet)
	if err != nil {
		custom_log("Error", "Failed to serialize layers for modified packet: %v", err)
		return []byte{}
	}
	return buffer.Bytes()
}

func vlan_arp_announce_loop() {
	for {
		if vlan_netdevice_handle == nil {
			time.Sleep(5000 * time.Millisecond)
			continue
		}
		eth := layers.Ethernet{
			SrcMAC:       MainProgramConfig.Vlan.RemoteMac_obj,
			DstMAC:       net.HardwareAddr{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
			EthernetType: layers.EthernetTypeARP,
		}
		arp_resp := layers.ARP{
			AddrType:          layers.LinkTypeEthernet,
			Protocol:          layers.EthernetTypeIPv4,
			HwAddressSize:     6,
			ProtAddressSize:   4,
			Operation:         layers.ARPRequest,
			SourceHwAddress:   MainProgramConfig.Vlan.RemoteMac_obj,
			SourceProtAddress: MainProgramConfig.Vlan.RemoteIP_obj,
			DstHwAddress:      []byte{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
			DstProtAddress:    MainProgramConfig.Vlan.RemoteIP_obj,
		}
		buffer := gopacket.NewSerializeBuffer()
		opts := gopacket.SerializeOptions{
			FixLengths:       true,
			ComputeChecksums: true,
		}
		gopacket.SerializeLayers(buffer, opts, &eth, &arp_resp)
		if err := vlan_netdevice_handle.WritePacketData(buffer.Bytes()); err != nil {
			custom_log("Trace", "Failed to inject ARP announce: %v", err)
		} else {
			custom_log("Trace", "Injected ARP announce")
		}
		time.Sleep(5000 * time.Millisecond)
	}
}

func hook_arp_handler(packet gopacket.Packet) bool {
	// simulate peer response
	arp_layer := packet.Layer(layers.LayerTypeARP)
	if arp_layer == nil {
		return false
	}
	arp, _ := arp_layer.(*layers.ARP)
	if arp.Operation != layers.ARPRequest {
		return false
	}

	if !bytes.Equal(arp.DstProtAddress, MainProgramConfig.Vlan.RemoteIP_obj) {
		return false
	}

	if bytes.Equal(arp.DstHwAddress, []byte{0xff, 0xff, 0xff, 0xff, 0xff, 0xff}) {
		return true
	}

	eth := layers.Ethernet{
		SrcMAC:       MainProgramConfig.Vlan.RemoteMac_obj,
		DstMAC:       MainProgramConfig.Vlan.LocalMac_obj,
		EthernetType: layers.EthernetTypeARP,
	}
	arp_resp := layers.ARP{
		AddrType:          layers.LinkTypeEthernet,
		Protocol:          layers.EthernetTypeIPv4,
		HwAddressSize:     6,
		ProtAddressSize:   4,
		Operation:         layers.ARPReply,
		SourceHwAddress:   MainProgramConfig.Vlan.RemoteMac_obj,
		SourceProtAddress: MainProgramConfig.Vlan.RemoteIP_obj,
		DstHwAddress:      arp.SourceHwAddress,
		DstProtAddress:    arp.SourceProtAddress,
	}
	buffer := gopacket.NewSerializeBuffer()
	opts := gopacket.SerializeOptions{
		FixLengths:       true,
		ComputeChecksums: true,
	}
	gopacket.SerializeLayers(buffer, opts, &eth, &arp_resp)
	if err := vlan_netdevice_handle.WritePacketData(buffer.Bytes()); err != nil {
		custom_log("Trace", "Failed to inject ARP response: %v", err)
	} else {
		custom_log("Trace", "Injected ARP response")
	}
	return true
}
