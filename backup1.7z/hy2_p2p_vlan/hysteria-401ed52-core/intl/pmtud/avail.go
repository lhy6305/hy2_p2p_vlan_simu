//go:build linux || windows || darwin

package pmtud

const (
	DisablePathMTUDiscovery = false
)
