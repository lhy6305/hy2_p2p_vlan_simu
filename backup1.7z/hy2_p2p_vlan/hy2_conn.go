package main

import (
	"context"
	"sync"

	hy2_quic "github.com/apernet/quic-go"
)

var (
	hy2_quic_conn              *hy2_quic.Connection = nil
	hy2_quic_conn_mutex        sync.RWMutex
	hy2_quic_conn_stream       *hy2_quic.Stream = nil
	hy2_quic_conn_stream_mutex sync.Mutex
)

func hy2_conn_create_stream() {
	hy2_quic_conn_mutex.RLock()
	defer hy2_quic_conn_mutex.RUnlock()
	if hy2_quic_conn == nil {
		custom_log("Error", "hy2_quic_conn is nil. Please initialize Hy2 connection first.")
		return
	}
	ctx, _ := context.WithTimeout(context.Background(), MainProgramConfig.Hy2.Client.OpenStreamTimeout)
	hy2_conn, err := (*hy2_quic_conn).OpenStreamSync(ctx)
	if err != nil {
		custom_log("Error", "Failed to open stream on Hy2 conn: %v", err)
		return
	}
	hy2_quic_conn_stream_mutex.Lock()
	if hy2_quic_conn_stream != nil {
		custom_log("Warn", "hy2_quic_conn_stream already established")
		hy2_conn.Close()
		hy2_quic_conn_stream_mutex.Unlock()
		return
	}
	hy2_quic_conn_stream = &hy2_conn
	hy2_conn.Write([]byte{0x1c}) // write data outside the QUIC protocol to trigger StreamHijacker
	hy2_quic_conn_stream_mutex.Unlock()
	custom_log("Info", "hy2_quic_conn_stream opened")
}
