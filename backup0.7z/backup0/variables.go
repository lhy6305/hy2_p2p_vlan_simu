package main

import (
	"crypto/tls"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io/ioutil"
	"os"
	"time"
)

// Variables that may be set by the user
var (
	config_file_path string = "config.json"
)

// Variables for json parsing

type Duration struct {
	time.Duration
}

func (d *Duration) UnmarshalJSON(b []byte) error {
	var v interface{}
	if err := json.Unmarshal(b, &v); err != nil {
		return err
	}
	switch value := v.(type) {
	case float64:
		d.Duration = time.Duration(value)
		return nil
	case string:
		var err error
		d.Duration, err = time.ParseDuration(value)
		if err != nil {
			return err
		}
		return nil
	default:
		return errors.New("invalid duration")
	}
}

type MainProgramConfig_hy2_quic_global_struct struct {
	StreamRecvWindowInit    uint64   `json:"stream_recv_window_init"`
	StreamRecvWindowMax     uint64   `json:"stream_recv_window_max"`
	ConnRecvWindowInit      uint64   `json:"conn_recv_window_init"`
	ConnRecvWindowMax       uint64   `json:"conn_recv_window_max"`
	MaxIdleTimeout_d        Duration `json:"max_idle_timeout"`
	MaxIdleTimeout          time.Duration
	DisablePathMTUDiscovery bool `json:"disable_path_mtu_discovery"`
}

type MainProgramConfig_hy2_global_struct struct {
	BandwidthSendMax uint64   `json:"bandwidth_send_max"`
	BandwidthRecvMax uint64   `json:"bandwidth_recv_max"`
	AuthParam        string   `json:"auth_param"`
	AuthTimeout_d    Duration `json:"client_auth_timeout"`
	AuthTimeout      time.Duration
}

type MainProgramConfig_struct struct {
	Clog struct {
		DebugMode           bool `json:"clog_debug_mode"`
		TraceMode           bool `json:"clog_trace_mode"`
		EnableColoredOutput bool `json:"clog_enable_colored_output"`
	} `json:"clog"`

	Tcp struct {
		DialTimeout_d Duration `json:"dial_timeout"`
		DialTimeout   time.Duration
	} `json:"tcp"`

	Hy2 struct {
		CopyBufferSize int `json:"copy_buffer"`

		Client struct {
			MainProgramConfig_hy2_global_struct
			OpenStreamTimeout_d Duration `json:"open_stream_timeout"`
			OpenStreamTimeout   time.Duration
			ConnLocalAddr       string `json:"conn_local_addr"`
			TlsServerName       string `json:"tls_server_name"`
			TlsAllowInsecure    bool   `json:"tls_allow_insecure"`
			Quic                struct {
				MainProgramConfig_hy2_quic_global_struct
				KeepaliveInterval_d Duration `json:"keepalive_interval"`
				KeepaliveInterval   time.Duration
			} `json:"quic"`
		} `json:"client"`

		Server struct {
			MainProgramConfig_hy2_global_struct
			Quic struct {
				MainProgramConfig_hy2_quic_global_struct
				MaxIncomingStreams int64 `json:"max_incoming_streams"`
			} `json:"quic"`
			IgnoreClientBandwidth bool `json:"ignore_client_bandwidth"`
		} `json:"server"`

		Certs []struct {
			Cert       string `json:"cert"`
			PrivateKey string `json:"private_key"`
		} `json:"certs"`
		CertsObj []tls.Certificate
	} `json:"hy2"`
}

var MainProgramConfig = MainProgramConfig_struct{}

func init_default_config() {
	MainProgramConfig.Clog.DebugMode = false
	MainProgramConfig.Clog.TraceMode = false
	MainProgramConfig.Clog.EnableColoredOutput = true

	MainProgramConfig.Tcp.DialTimeout_d = Duration{3 * time.Second}

	MainProgramConfig.Hy2.CopyBufferSize = 32 * 1024

	MainProgramConfig.Hy2.Client.ConnLocalAddr = ""
	MainProgramConfig.Hy2.Client.TlsAllowInsecure = false
	MainProgramConfig.Hy2.Client.AuthParam = ""
	MainProgramConfig.Hy2.Client.TlsServerName = ""
	MainProgramConfig.Hy2.Client.BandwidthSendMax = 0
	MainProgramConfig.Hy2.Client.BandwidthRecvMax = 0
	MainProgramConfig.Hy2.Client.OpenStreamTimeout_d = Duration{3 * time.Second}
	MainProgramConfig.Hy2.Client.AuthTimeout_d = Duration{3 * time.Second}
	MainProgramConfig.Hy2.Client.Quic.MaxIdleTimeout_d = Duration{30 * time.Second}
	MainProgramConfig.Hy2.Client.Quic.KeepaliveInterval_d = Duration{10 * time.Second}
	MainProgramConfig.Hy2.Client.Quic.DisablePathMTUDiscovery = false
	MainProgramConfig.Hy2.Client.Quic.StreamRecvWindowInit = 0
	MainProgramConfig.Hy2.Client.Quic.StreamRecvWindowMax = 8 * 1024 * 1024
	MainProgramConfig.Hy2.Client.Quic.ConnRecvWindowInit = 0
	MainProgramConfig.Hy2.Client.Quic.ConnRecvWindowMax = 20 * 1024 * 1024

	MainProgramConfig.Hy2.Server.IgnoreClientBandwidth = false
	MainProgramConfig.Hy2.Server.AuthParam = ""
	MainProgramConfig.Hy2.Server.BandwidthSendMax = 0
	MainProgramConfig.Hy2.Server.BandwidthRecvMax = 0
	MainProgramConfig.Hy2.Server.AuthTimeout_d = Duration{3 * time.Second}
	MainProgramConfig.Hy2.Server.Quic.MaxIdleTimeout_d = Duration{30 * time.Second}
	MainProgramConfig.Hy2.Server.Quic.MaxIncomingStreams = 1024
	MainProgramConfig.Hy2.Server.Quic.DisablePathMTUDiscovery = false
	MainProgramConfig.Hy2.Server.Quic.StreamRecvWindowInit = 0
	MainProgramConfig.Hy2.Server.Quic.StreamRecvWindowMax = 8 * 1024 * 1024
	MainProgramConfig.Hy2.Server.Quic.ConnRecvWindowInit = 0
	MainProgramConfig.Hy2.Server.Quic.ConnRecvWindowMax = 20 * 1024 * 1024
}

func init() {
	config_init1()
	config_init2()
	config_init3()
}

func config_init1() {
	flag.StringVar(&config_file_path, "config", config_file_path, "")

	flag.Usage = func() {
		fmt.Fprintf(flag.CommandLine.Output(), "hy2_tnl program by ly65")
		fmt.Fprintf(flag.CommandLine.Output(), "\n")
		fmt.Fprintf(flag.CommandLine.Output(), "ly65-miao don't know how to use it, though...\r")
		fmt.Fprintf(flag.CommandLine.Output(), "                                             \n")
		fmt.Fprintf(flag.CommandLine.Output(), "Usage: %s [flags...]", os.Args[0])
		fmt.Fprintf(flag.CommandLine.Output(), "\n")
		flag.PrintDefaults()
	}

	flag.Parse()

	init_default_config()

	config_file, err := os.Open("config.json")
	if err != nil {
		custom_log("Warn", "Config file not readable, using default config: %v", err)
		return
	}
	defer config_file.Close()

	decoder := json.NewDecoder(config_file)
	decoder.DisallowUnknownFields()
	err1 := decoder.Decode(&MainProgramConfig)

	if err1 != nil {
		ret, err := config_file.Seek(0, 0)
		if ret != 0 || err != nil {
			custom_log("Fatal", "Failed to parse config: %v", err)
			os.Exit(1)
			return
		}
		decoder = json.NewDecoder(config_file)
		err = decoder.Decode(&MainProgramConfig)
		if err != nil {
			custom_log("Fatal", "Failed to parse config: %v", err)
			os.Exit(1)
			return
		}
		custom_log("Warn", "Unknown fields found: %v", err1)
	}

	custom_log("Info", "Config file parsed successfully")
}

func config_init2() {
	// copy time.Duration

	MainProgramConfig.Tcp.DialTimeout = MainProgramConfig.Tcp.DialTimeout_d.Duration
	MainProgramConfig.Hy2.Client.OpenStreamTimeout = MainProgramConfig.Hy2.Client.OpenStreamTimeout_d.Duration
	MainProgramConfig.Hy2.Client.AuthTimeout = MainProgramConfig.Hy2.Client.AuthTimeout_d.Duration
	MainProgramConfig.Hy2.Client.Quic.MaxIdleTimeout = MainProgramConfig.Hy2.Client.Quic.MaxIdleTimeout_d.Duration
	MainProgramConfig.Hy2.Client.Quic.KeepaliveInterval = MainProgramConfig.Hy2.Client.Quic.KeepaliveInterval_d.Duration
	MainProgramConfig.Hy2.Server.AuthTimeout = MainProgramConfig.Hy2.Server.AuthTimeout_d.Duration
	MainProgramConfig.Hy2.Server.Quic.MaxIdleTimeout = MainProgramConfig.Hy2.Server.Quic.MaxIdleTimeout_d.Duration

	// parse certs

	MainProgramConfig.Hy2.CertsObj = make([]tls.Certificate, 0)
	for _, conf := range MainProgramConfig.Hy2.Certs {
		cert_str, err := ioutil.ReadFile(conf.Cert)
		if err != nil {
			custom_log("Error", "Failed to read certificate %s: %v", conf.Cert, err)
			continue
		}

		private_key_str, err := ioutil.ReadFile(conf.PrivateKey)
		if err != nil {
			custom_log("Error", "Failed to read private key %s: %v", conf.PrivateKey, err)
			continue
		}

		cert_obj, err := tls.X509KeyPair(cert_str, private_key_str)
		if err != nil {
			custom_log("Error", "Failed to load certificate %s: %v", conf.Cert, err)
			continue
		}

		MainProgramConfig.Hy2.CertsObj = append(MainProgramConfig.Hy2.CertsObj, cert_obj)
		custom_log("Info", "Certificate file %s loaded successfully", conf.Cert)
	}
}

func config_init3() {
	if MainProgramConfig.Hy2.Client.TlsAllowInsecure {
		custom_log("Warn", "TlsAllowInsecure enabled on client")
	}
	if len(MainProgramConfig.Hy2.Server.AuthParam) <= 0 {
		custom_log("Warn", "AuthParam is empty on the server. The server will accept any connection. This is not recommended.")
	}
}
