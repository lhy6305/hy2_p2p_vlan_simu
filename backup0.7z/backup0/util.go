package main

import (
	"crypto/rand"
	"encoding/hex"
	"io"
)

func gen_random_id(length int) string {
	rand_bytes := make([]byte, (length+1)/2)
	_, err := rand.Read(rand_bytes)
	if err != nil {
		custom_log("Error", "GenRandomId() failed: %v", err)
		return "Fallback_AuthID_because_GenRandomId_Failed"
	}
	return hex.EncodeToString(rand_bytes)[:length]
}

func copy_two_way(peer1 io.ReadWriter, peer2 io.ReadWriter) error {
	err_chan := make(chan error, 2)
	go func() {
		buf := make([]byte, MainProgramConfig.Hy2.CopyBufferSize)
		_, err := io.CopyBuffer(peer1, peer2, buf)
		err_chan <- err
	}()
	go func() {
		buf := make([]byte, MainProgramConfig.Hy2.CopyBufferSize)
		_, err := io.CopyBuffer(peer2, peer1, buf)
		err_chan <- err
	}()
	return <-err_chan
}
