package main

import (
	"context"
	"fmt"
	"net"
	"sync"

	hy2_quic "github.com/apernet/quic-go"
)

var (
	hy2_quic_conn       *hy2_quic.Connection = nil
	hy2_quic_conn_mutex sync.RWMutex
)

type CNetConn struct {
	ConnType    string
	TCPConn     *net.Conn
	UDPConn     *net.PacketConn
	UDPConnAddr *net.Addr
	Hy2Conn     *hy2_quic.Stream
	LocalAddr   string
	RemoteAddr  string
	mutex       sync.RWMutex
	isClosed    bool
}

func DialCNetTCP(raddr string) *CNetConn {
	raddr_tcp, err := net.ResolveTCPAddr("tcp", raddr)
	if err != nil {
		custom_log("Error", "Resolve TCP address failed for %s: %v", raddr, err)
		return nil
	}
	conn, err := net.DialTimeout("tcp", raddr_tcp.String(), MainProgramConfig.Tcp.DialTimeout)
	if err != nil {
		custom_log("Error", "Dial TCP failed for %s: %v", raddr, err)
		conn.Close()
		return nil
	}
	return &CNetConn{
		TCPConn:    &conn,
		ConnType:   "tcp",
		LocalAddr:  conn.LocalAddr().String(),
		RemoteAddr: conn.RemoteAddr().String(),
	}
}

func DialCNetUDP(raddr string) *CNetConn {
	raddr_udp, err := net.ResolveUDPAddr("udp", raddr)
	if err != nil {
		custom_log("Error", "Resolve UDP address failed for %s: %v", raddr, err)
		return nil
	}
	conn, err := net.ListenUDP("udp", nil)
	if err != nil {
		custom_log("Error", "Listen UDP failed for %s: %v", raddr, err)
		conn.Close()
		return nil
	}
	var packet_conn net.PacketConn = conn
	var addr_interface net.Addr = raddr_udp
	return &CNetConn{
		UDPConn:     &packet_conn,
		UDPConnAddr: &addr_interface,
		ConnType:    "udp",
		LocalAddr:   conn.LocalAddr().String(),
		RemoteAddr:  conn.RemoteAddr().String(),
	}
}

func DialCNetHy2() *CNetConn {
	hy2_quic_conn_mutex.RLock()
	defer hy2_quic_conn_mutex.RUnlock()
	if hy2_quic_conn == nil {
		custom_log("Error", "hy2_quic_conn is nil. Please initialize Hy2 connection first.")
		return nil
	}
	ctx, _ := context.WithTimeout(context.Background(), MainProgramConfig.Hy2.Client.OpenStreamTimeout)
	hy2_conn, err := (*hy2_quic_conn).OpenStreamSync(ctx)
	if err != nil {
		custom_log("Error", "Failed to open stream on Hy2 conn: %v", err)
		return nil
	}
	return &CNetConn{
		Hy2Conn:    &hy2_conn,
		ConnType:   "hy2",
		LocalAddr:  "",
		RemoteAddr: "",
	}
}

func (c *CNetConn) Read(p []byte) (n int, err error) {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	if c.isClosed {
		return 0, fmt.Errorf("connection already closed")
	}
	conn_nil_flag := false
	switch c.ConnType {
	case "tcp":
		if c.TCPConn != nil {
			return (*c.TCPConn).Read(p)
		}
		conn_nil_flag = true
	case "udp":
		if c.UDPConn != nil {
			n, _, err := (*c.UDPConn).ReadFrom(p)
			return n, err
		}
		conn_nil_flag = true
	case "hy2":
		if c.Hy2Conn != nil {
			return (*c.Hy2Conn).Read(p)
		}
		conn_nil_flag = true
	}
	if conn_nil_flag {
		custom_log("Logic Error", "Got type %s, but it's connection is nil", c.ConnType)
		return 0, fmt.Errorf("%s connection is nil", c.ConnType)
	}
	return 0, fmt.Errorf("connection type %s not recognized", c.ConnType)
}

func (c *CNetConn) Write(p []byte) (n int, err error) {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	if c.isClosed {
		return 0, fmt.Errorf("connection already closed")
	}
	conn_nil_flag := false
	switch c.ConnType {
	case "tcp":
		if c.TCPConn != nil {
			return (*c.TCPConn).Write(p)
		}
		conn_nil_flag = true
	case "udp":
		if c.UDPConn != nil {
			if c.UDPConnAddr != nil {
				return (*c.UDPConn).WriteTo(p, (*c.UDPConnAddr))
			}
			custom_log("Logic Error", "Got type %s, but it's UDPConnAddr is nil", c.ConnType)
			return 0, fmt.Errorf("%s connection is nil", c.ConnType)
		}
		conn_nil_flag = true
	case "hy2":
		if c.Hy2Conn != nil {
			return (*c.Hy2Conn).Write(p)
		}
		conn_nil_flag = true
	}
	if conn_nil_flag {
		custom_log("Logic Error", "Got type %s, but it's connection is nil", c.ConnType)
		return 0, fmt.Errorf("%s connection is nil", c.ConnType)
	}
	return 0, fmt.Errorf("connection type %s not recognized", c.ConnType)
}

func (c *CNetConn) Close() {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	c.isClosed = true
	c.ConnType = ""
	if c.TCPConn != nil {
		(*c.TCPConn).Close()
		c.TCPConn = nil
	}
	if c.UDPConn != nil {
		(*c.UDPConn).Close()
		c.UDPConn = nil
	}
	if c.UDPConnAddr != nil {
		c.UDPConnAddr = nil
	}
	if c.Hy2Conn != nil {
		(*c.Hy2Conn).Close()
		c.Hy2Conn = nil
	}
}
