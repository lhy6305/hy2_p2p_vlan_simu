package main

import ()

func main() {
	go iaterm_loop()
	select {}
}
