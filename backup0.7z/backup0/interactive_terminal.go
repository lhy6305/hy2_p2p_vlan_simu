package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func iaterm_clog_output_done_hook() {
	fmt.Print("> ")
}

func iaterm_loop() {
	scanner := bufio.NewScanner(os.Stdin)
	clog_println("")
	clog_println("##### Interactive Terminal #####")
	clog_println("Use `help` to view available commands")
	clog_println("")

	for {
		fmt.Print("\r   \r> ")
		if !scanner.Scan() {
			break
		}

		line := scanner.Text()

		parts := strings.Fields(line)
		if len(parts) == 0 {
			continue
		}

		switch parts[0] {
		case "exit":
			os.Exit(0)

		case "help":
			clog_println("===== Command List =====")

			clog_println("`hy2 connect <raddr>`: Connect as a client to <raddr>")
			clog_println("`hy2 serve <laddr>`: Start a server listening on <laddr>")
			clog_println("`hy2 status`: Show the status of the Hy2 service")
			clog_println("`hy2 stop`: Disconnect the client or stop the server")

			clog_println("`tnl create <type:tcp|udp> <laddr> <raddr> [lrole:listener(default)|dialer]`: Create a data tunnel")
			clog_println("`tnl close <id>`: Close the specified data tunnel")
			clog_println("`tnl list`: List all data tunnels")

			clog_println("========================")

		case "hy2":
			if len(parts) < 2 {
				clog_println("Command `hy2` requires at least 1 param")
				continue
			}
			switch parts[1] {
			case "connect":
				if len(parts) < 3 {
					clog_println("Action `connect` requires at least 1 param")
					continue
				}
				addr := parts[2]
				//go hy2_client_start(addr)
				hy2_client_start(addr)

			case "serve":
				if len(parts) < 3 {
					clog_println("Action `serve` requires at least 1 param")
					continue
				}
				addr := parts[2]
				//go hy2_server_start(addr)
				hy2_server_start(addr)

			case "status":
				if hy2_quic_conn != nil {
					clog_println("hy2_quic_conn is created")
				} else {
					clog_println("hy2_quic_conn is nil")
				}

				if hy2_client_instance != nil {
					clog_println("hy2_client_instance is created")
				} else if hy2_server_instance != nil {
					clog_println("hy2_server_instance is created")
				} else {
					clog_println("hy2_instance NOT found")
				}

			case "stop":
				if hy2_quic_conn != nil {
					(*hy2_quic_conn).CloseWithError(0x010c, "Manual Disconnect") //H3_REQUEST_CANCELLED
					clog_println("hy2_quic_conn closed")
					//hy2_quic_conn = nil
				}
				if hy2_client_instance != nil {
					hy2_client_instance.Close()
					clog_println("hy2_client_instance closed")
					//hy2_client_instance = nil
				}
				if hy2_server_instance != nil {
					hy2_server_instance.Close()
					clog_println("hy2_server_instance closed")
					//hy2_server_instance = nil
				}

			default:
				clog_printf("Unknown action `%s`\n", parts[1])
			}

		case "tnl":
			if len(parts) < 2 {
				clog_println("Command `tnl` requires at least 1 param")
				continue
			}
			switch parts[1] {
			case "create":
				if len(parts) < 5 {
					clog_println("Action `create` requires at least 3 params")
					continue
				}
				protocol_type_str := parts[2]
				laddr := parts[3]
				raddr := parts[4]
				lrole_str := "listener"
				if len(parts) > 5 {
					lrole_str = parts[5]
				}
				protocol_type := tnlprotocol_string_to_ptype(protocol_type_str)
				lrole := tnlprotocol_string_to_role(lrole_str)
				if hy2_quic_conn == nil {
					clog_println("Error: Hy2 connection not established")
					continue
				}
				clog_printf("Action Not Implemented: create(0x%02x, %s, %s, 0x%02x)\n", protocol_type, laddr, raddr, lrole)
				// 这里可以调用相应的函数处理隧道创建操作

			case "list":
				li := conn_pool_list()
				clog_printf("===== Total: %d =====\n", len(li))
				for _, it := range li {
					clog_println(it)
				}
				clog_println("====================")

			case "close":
				if len(parts) < 3 {
					clog_println("Action `close` requires at least 1 param")
					continue
				}
				if ok := conn_pool_remove(parts[2]); ok {
					clog_printf("Tunnel %s removed\n", parts[2])
				} else {
					clog_printf("Tunnel %s not found\n", parts[2])
				}

			default:
				clog_printf("Unknown action `%s`\n", parts[1])
			}

		default:
			clog_printf("Unknown command `%s`\n", parts[0])
		}
	}
	if err := scanner.Err(); err != nil {
		custom_log("Error", "Stdin closed unexpectly: %v", err)
	}
}
