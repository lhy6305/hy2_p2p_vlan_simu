package main

import (
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"net"

	hy2_quic "github.com/apernet/quic-go"
)

func hy2_conn_serve_loop() {
	if !hy2_quic_conn_mutex.TryRLock() {
		custom_log("Error", "A Hy2 conn instance is already established! Close it before making a new one")
		return
	}
	defer hy2_quic_conn_mutex.RUnlock()
	if hy2_quic_conn == nil {
		custom_log("Error", "hy2_quic_conn is nil. Please initialize Hy2 connection first.")
		return
	}
	custom_log("Info", "Hy2 quic conn serve loop started")
	for {
		conn, err := (*hy2_quic_conn).AcceptStream(context.Background())
		if err != nil {
			if aerr, ok := err.(*hy2_quic.ApplicationError); ok && aerr.ErrorCode == 0x010c {
				custom_log("Info", "Hy2 quic conn serve loop stopped: Manual Disconnect")
				return
			}
			custom_log("Error", "Failed to keep Hy2 quic conn serve loop: %v", err)
			return
		}
		hy2_conn_handler(&conn)
	}
}

func hy2_conn_handler(conn *hy2_quic.Stream) {
	if conn == nil {
		custom_log("Logic Error", "conn is nil")
		return
	}

	msg_header := make([]byte, 5)
	_, err := io.ReadFull((*conn), msg_header)
	if err != nil {
		custom_log("Warn", "Failed to parse message header: %v", err)
		(*conn).Close()
		return
	}

	protocol_version := msg_header[0]
	local_type := msg_header[1]
	local_port := binary.BigEndian.Uint16(msg_header[2:4])
	local_role := msg_header[4]

	if protocol_version != CurProtocolVersion {
		custom_log("Warn", "Unsupported protocol version %d", protocol_version)
		(*conn).Close()
		return
	}

	var local_conn *CNetConn
	local_addr := net.JoinHostPort("", fmt.Sprintf("%u", local_port))

	switch local_type {
	case TnlProtocolTCP:
		switch local_role {
		case TnlRoleListener:
			//local_conn = DialCNetTCP(local_addr)
		case TnlRoleDialer:
			local_conn = DialCNetTCP(local_addr)
		default:
			custom_log("Warn", "Peer sent unrecognized role 0x%02x", local_role)
			(*conn).Close()
		}
	case TnlProtocolUDP:
		switch local_role {
		case TnlRoleListener:
			local_conn = NewCNetUDP(local_addr)
		case TnlRoleDialer:
			local_conn = NewCNetUDP(local_addr)
		default:
			custom_log("Warn", "Peer sent unrecognized role 0x%02x", local_role)
			(*conn).Close()
		}
	default:
		custom_log("Warn", "Peer sent unrecognized protocol_type 0x%02x", local_type)
		(*conn).Close()
		return
	}

	if local_conn == nil {
		custom_log("Connection Error", "failed to create peer connection")
		(*conn).Close()
		return
	}

	rconn := &CNetConn{
		Hy2Conn:    conn,
		ConnType:   "hy2",
		LocalAddr:  "",
		RemoteAddr: "",
	}

	conn_pool_add(rconn, local_conn, local_type, local_port, local_role)
}
