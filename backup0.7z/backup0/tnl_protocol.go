package main

const (
	CurProtocolVersion = 0x01
	TnlProtocolUnknown = 0x00
	TnlProtocolTCP     = 0x01
	TnlProtocolUDP     = 0x02
	TnlRoleUnknown     = 0x00
	TnlRoleListener    = 0x01
	TnlRoleDialer      = 0x02
)

func tnlprotocol_ptype_to_string(pt byte) string {
	switch pt {
	case TnlProtocolTCP:
		return "tcp"
	case TnlProtocolUDP:
		return "udp"
	}
	return "unknown"
}

func tnlprotocol_string_to_ptype(str string) byte {
	switch str {
	case "tcp":
		return TnlProtocolTCP
	case "udp":
		return TnlProtocolUDP
	}
	return TnlProtocolUnknown
}

func tnlprotocol_role_to_string(role byte) string {
	switch role {
	case TnlRoleListener:
		return "listener"
	case TnlRoleDialer:
		return "dialer"
	}
	return "unknown"
}

func tnlprotocol_string_to_role(str string) byte {
	switch str {
	case "listener":
		return TnlRoleListener
	case "dialer":
		return TnlRoleDialer
	}
	return TnlRoleUnknown
}
