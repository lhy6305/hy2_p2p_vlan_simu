package main

import (
	"fmt"
	"sync"
)

type conn_pool_item_struct struct {
	conn1      *CNetConn
	conn2      *CNetConn
	local_type byte
	local_port uint16
	local_role byte
	str_id     string
	is_closed  bool
	mutex      sync.RWMutex
}

func (conn_item *conn_pool_item_struct) Close() {
	conn_item.mutex.Lock()
	defer conn_item.mutex.Unlock()
	if conn_item.is_closed {
		return
	}
	conn_item.is_closed = true
	conn_item.conn1.Close()
	conn_item.conn2.Close()
}

var (
	conn_pool       []*conn_pool_item_struct
	conn_pool_mutex sync.RWMutex
)

func conn_pool_add(conn1 *CNetConn, conn2 *CNetConn, local_type byte, local_port uint16, local_role byte) {
	conn_pool_mutex.Lock()
	defer conn_pool_mutex.Unlock()

	conn_item := &conn_pool_item_struct{
		conn1:      conn1,
		conn2:      conn2,
		local_type: local_type,
		local_port: local_port,
		local_role: local_role,
		str_id:     fmt.Sprintf("%s:%s:%u", tnlprotocol_ptype_to_string(local_type), tnlprotocol_role_to_string(local_role), local_port),
	}

	conn_pool = append(conn_pool, conn_item)

	go func(conn_item *conn_pool_item_struct) {
		err := copy_two_way(conn_item.conn1, conn_item.conn2) // block until an error occurs (assuming the connection is closed)
		custom_log("Debug", "Conn closed: %v", err)
		conn_item.Close()
	}(conn_item)
}

func conn_pool_get(i int) (bool, string) {
	conn_pool_mutex.RLock()
	defer conn_pool_mutex.RUnlock()

	conn_pool[i].mutex.RLock()
	if !conn_pool[i].is_closed {
		conn_pool[i].mutex.RUnlock()
		return true, conn_pool[i].str_id
	}
	conn_pool[i].mutex.RUnlock()

	return false, ""
}

func conn_pool_list() []string {
	conn_pool_mutex.RLock()
	defer conn_pool_mutex.RUnlock()

	var res []string

	for _, conn_item := range conn_pool {
		conn_item.mutex.RLock()
		if !conn_item.is_closed {
			conn_item.mutex.RUnlock()
			res = append(res, conn_item.str_id)
		}
		conn_item.mutex.RUnlock()
	}
	return res
}

func conn_pool_clean() {
	conn_pool_mutex.Lock()
	defer conn_pool_mutex.Unlock()
	for i := len(conn_pool) - 1; i >= 0; i-- {
		if conn_pool[i].is_closed {
			conn_pool = append(conn_pool[:i], conn_pool[i+1:]...)
		}
	}
}

func conn_pool_remove(str_id string) bool {
	conn_pool_mutex.Lock()
	defer conn_pool_mutex.Unlock()

	for i := 0; i < len(conn_pool); i++ {
		if conn_pool[i].str_id == str_id {
			conn_pool[i].Close()
			conn_pool = append(conn_pool[:i], conn_pool[i+1:]...)
			//i-- //useless due to the next return statement
			return true
		}
	}
	return false
}
